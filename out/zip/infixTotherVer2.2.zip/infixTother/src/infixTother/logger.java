

package infixTother;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class logger {

    private static String StackLog = "";
    private static String CurrentOutput = "";


    public static void StackPushLog(char Log){
        StackLog = StackLog + Log;
        Controller.getInstance().setLogArea("Stack Push:" + Log);
        Controller.getInstance().setLogArea("Stack     :" + StackLog);
        OutputLog('\0');
    }

    public static void StackPopLog(char Log){
        if (!StackLog.isEmpty() && StackLog.charAt(StackLog.length()-1) == Log){
            StackLog = StackLog.substring(0,StackLog.length()-1);
        }
        Controller.getInstance().setLogArea("Stack Pop :" + Log);
        Controller.getInstance().setLogArea("Stack     :" + StackLog);
        if (Log !='(' && Log !=')')OutputLog(Log);
    }

    public static void OutputLog(char OLog){
        CurrentOutput = CurrentOutput + OLog;
        Controller.getInstance().setLogArea("Output    :" + CurrentOutput);
    }

    public static void ClearLog(){
        StackLog = "";
        CurrentOutput = "";
    }
}
