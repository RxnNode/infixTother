package infixTother;

import java.lang.StringBuilder;
import java.lang.Character;
import java.util.Stack;

public class infixTother {

    private static char[] infixArr;

    /*public static void infixTother(String strinfix){
        infixArr = StrToChar(strinfix);
        infixToPrefix(infixArr);
        System.out.println("\n");
        infixToPostfix(infixArr);
    }*/

    public static String infixToPrefix(String Strinfix){
        Stack<Character> stack = new Stack<Character>();
        infixArr = StrToChar(Strinfix);
        char[] PrefixArr = new char[infixArr.length];
        int l = 0;
        int i = infixArr.length - 1;
        System.out.println("Current String:"+Strinfix);
        while (i>=0){
            if (infixArr[i] !=' '){
                switch (infixArr[i]){
                    case ')':
                        stack.push(infixArr[i]);
                        logger.StackPushLog(infixArr[i]);
                        i--;
                        break;
                    case '+': case '-': case '*': case '/': case '^':
                        while(!stack.isEmpty() && priority(stack.peek())>priority(infixArr[i])){
                            //System.out.print(stack.pop());
                            if (stack.peek()!=')'){
                                PrefixArr[l]=stack.pop();
                                logger.StackPopLog(PrefixArr[l]);
                                l++;
                            }else {
                                logger.StackPopLog(stack.pop());
                            }
                        }
                        stack.push(infixArr[i]);
                        logger.StackPushLog(infixArr[i]);
                        i--;
                        break;
                    case '(':
                        while (stack.peek()!=')'){
                            //System.out.print(stack.pop());
                            PrefixArr[l]=stack.pop();
                            logger.StackPopLog(PrefixArr[l]);
                            l++;
                        }
                        logger.StackPopLog(stack.pop());
                        i--;
                        break;
                    default:
                        //System.out.print(infixArr[i]);
                        PrefixArr[l]=infixArr[i];
                        logger.OutputLog(PrefixArr[l]);
                        l++;
                        i--;
                        break;
                }
            }else {
                i--;
            }
        }
        while (!stack.isEmpty()){
            //System.out.print(stack.pop());
            if (stack.peek()!=')'){
                PrefixArr[l]=stack.pop();
                logger.StackPopLog(PrefixArr[l]);
                l++;
            }else {
                logger.StackPopLog(stack.pop());
            }
        }
        logger.ClearLog();
        String rev = new StringBuilder(String.valueOf(PrefixArr)).reverse().toString();
        Calculator.PrefixCal(rev);
    return rev;
    }



    public static String infixToPostfix(String Strinfix){
        Stack<Character> stack = new Stack<Character>();
        infixArr = StrToChar(Strinfix);
        char[] PostfixArr = new char[infixArr.length];
        int l = 0;
        String temp ="";
        int i = 0;
        while (i < infixArr.length){
            if (infixArr[i] !=' '){
                switch (infixArr[i]){
                    case '(':
                        stack.push(infixArr[i]);
                        logger.StackPushLog(infixArr[i]);
                        i++;
                        break;
                    case '+': case '-': case '*': case '/':case '^':
                        while(!stack.isEmpty() && priority(stack.peek())>=priority(infixArr[i])){
                            //System.out.print(stack.pop());
                            if (stack.peek()!='('){
                                PostfixArr[l]=stack.pop();
                                logger.StackPopLog(PostfixArr[l]);
                                l++;
                            }else {
                                logger.StackPopLog(stack.pop());
                            }
                        }
                        stack.push(infixArr[i]);
                        logger.StackPushLog(infixArr[i]);
                        i++;
                        break;
                    case ')':
                        while (stack.peek()!='('){
                            //System.out.println("ddpeek"+stack.peek());
                            PostfixArr[l]=stack.pop();
                            logger.StackPopLog(PostfixArr[l]);
                            l++;
                        }
                        i++;
                        break;
                    default:
                        //System.out.print(infixArr[i]);
                        PostfixArr[l]=infixArr[i];
                        logger.OutputLog(PostfixArr[l]);
                        l++;
                        i++;
                        break;
                }
            }else {
                i++;
            }
        }
        while (!stack.isEmpty()) {
            //System.out.print(stack.pop());
            if (stack.peek()!='('){
                PostfixArr[l]=stack.pop();
                logger.StackPopLog(PostfixArr[l]);
                l++;
            }else {
                logger.StackPopLog(stack.pop());
            }
        }
        //for(int j=0;j<PostfixArr.length;j++) System.out.print(PostfixArr[j]);
        logger.ClearLog();
        temp = String.valueOf(PostfixArr);
        Calculator.PostfixCal(temp);
        return temp;
    }

    /*
    優先權比較
     */
    private static int priority(char p){
        switch(p) {
            case '+': case '-':
                return 1;
            case '*': case '/':
                return 2;
            case '^':
                return 3;
            default:
                return 0;
        }
    }

    /*
    String轉換成char array
     */
    private static char[] StrToChar(String str){
        char[] CharArr = str.toCharArray();

        //for (int i=0; i<CharArr.length-1; i++) {
        //    System.out.println(CharArr[i]); }
        return CharArr;
    }


}
